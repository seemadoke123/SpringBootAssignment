package com.scms.demo.enums;

public enum OrderStatus {
    PENDING, COMPLETED, CANCELLED
}
