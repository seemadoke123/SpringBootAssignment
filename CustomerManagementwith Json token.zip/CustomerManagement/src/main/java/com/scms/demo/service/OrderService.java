package com.scms.demo.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scms.demo.entity.Order;
import com.scms.demo.enums.OrderStatus;
import com.scms.demo.repository.OrderRepository;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
	
	 Logger log = LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private OrderRepository orderRepository;

    public List<Order> getAllOrders() {
        log.info("Fetching all orders");
        return orderRepository.findAll();
    }

    public Optional<Order> getOrderById(Long id) {
        log.info("Fetching order with ID: {}", id);
        return orderRepository.findById(id);
    }

    public Order saveOrder(Order order) {
        log.info("Saving new order: {}", order);
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        log.info("Deleting order with ID: {}", id);
        orderRepository.deleteById(id);
    }

    public List<Order> getOrdersByCustomerId(Long customerId) {
        log.info("Fetching orders for customer ID: {}", customerId);
        return orderRepository.findByCustomerId(customerId);
    }

    public Order updateOrderStatus(Long orderId, OrderStatus newStatus) {
        log.info("Updating order ID {} to status {}", orderId, newStatus);
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        
        order.setStatus(newStatus);
        return orderRepository.save(order);
    }
}
