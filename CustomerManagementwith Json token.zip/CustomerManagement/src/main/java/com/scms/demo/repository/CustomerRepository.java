package com.scms.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.scms.demo.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
